package com.suyeon.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.suyeon.service.TestService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

//경로 주의
//패키지 처음 만들 때 com.suyeon.spring
@Log4j
@RequestMapping("/test/*")
//@AllArgsConstructor
@Controller
public class TestController {
		
	@Setter(onMethod_ = @Autowired)
	private TestService service;
	
	@GetMapping("/testurl")
	public void testurl() {
		
	}
	
	
	
}
